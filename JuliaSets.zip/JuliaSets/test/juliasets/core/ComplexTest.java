package juliasets.core;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ComplexTest {

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testComplexDoubleDouble() {
		fail("Not yet implemented");
	}

	@Test
	void testComplex() {
		fail("Not yet implemented");
	}

	@Test
	void testGetReal() {
		fail("Not yet implemented");
	}

	@Test
	void testGetImaginary() {
		fail("Not yet implemented");
	}

	@Test
	void testPlus() {
		fail("Not yet implemented");
	}

	@Test
	void testTimes() {
		fail("Not yet implemented");
	}

	@Test
	void testModulus() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

}
